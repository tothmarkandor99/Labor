package hu.bme.aut.android.telephonydemo

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.telephony.SmsManager
import android.view.View.OnClickListener
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_send_sms.*

class SendSMSActivity : Activity() {

    // kozos esemenykezelo a ket SMS kuldo gombhoz
    private var sendSms: OnClickListener = OnClickListener { v ->
        val phoneNumber = etPhoneNumber.text.toString()
        val messageText = etMessageText.text.toString()

        when (v.id) {

            R.id.btnSendIntent -> {
                // SMS kuldese Implicit Intent-tel
                val sendSmsIntent = Intent()

                // akcio: ACTION_SENDTO
                sendSmsIntent.action = Intent.ACTION_SENDTO

                // adat = Uri.parse(sms:[telefonszam])
                sendSmsIntent.data = Uri.parse("sms:$phoneNumber")

                // SMS szovege intent extra-kent kerul be
                sendSmsIntent.putExtra("sms_body", messageText)

                // intent inditasa
                try {
                    startActivity(sendSmsIntent)
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(
                            applicationContext,
                            "Nincs SMS küldő alkalmazás!",
                            Toast.LENGTH_LONG).show()
                }
            }

            R.id.btnSendProg -> {
                // SMS kuldese programozottan
                val smsManager = SmsManager.getDefault()
                smsManager.sendTextMessage(
                        phoneNumber, // cimzett telefonszam
                        null, // SMS szolgaltatokozpont telefonszama, null = default
                        messageText, // uzenet szovege
                        null, // opcionalis PendingIntent az uzenet elkuldesere
                        null // opcionalis PendingIntent az uzenet kezbesitesere
                )

                Toast.makeText(applicationContext, "SMS küldés megkezdve", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_send_sms)

        btnSendIntent.setOnClickListener(sendSms)
        btnSendProg.setOnClickListener(sendSms)
    }

}
