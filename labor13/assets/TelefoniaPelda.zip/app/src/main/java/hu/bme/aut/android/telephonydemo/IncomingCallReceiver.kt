package hu.bme.aut.android.telephonydemo

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.widget.Toast

class IncomingCallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val extras = intent.extras ?: return

        val callState = extras.getString(TelephonyManager.EXTRA_STATE)

        when (callState) {
            // minket most csak a bejovo hivas erdekel
            TelephonyManager.EXTRA_STATE_RINGING -> {
                // hivo telefonszam
                val incomingNumber = extras.getString(TelephonyManager.EXTRA_INCOMING_NUMBER)
                // Toast megjelenitese
                Toast.makeText(
                        context,
                        "Hivas felugyelo!\n Uj bejovo hivas a kovetkezo telefonszamrol: " + incomingNumber!!,
                        Toast.LENGTH_LONG).show()
            }

            // opcionalis: tovabbi allapotvaltasok lekezelese
            // (EXTRA_STATE_IDLE, EXTRA_STATE_OFFHOOK)
        }
    }

}
