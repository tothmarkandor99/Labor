package hu.bme.aut.amorg.examples.telefoniapelda;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

	public class OutgoingCallReceiver extends BroadcastReceiver {
	
		@Override
		public void onReceive(Context context, Intent intent) {
			
			Bundle extras = intent.getExtras();
			
			// null vizsgalat
			if(extras == null)
				return;
			
			// hivott telefonszam
			String phoneNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
			
			// Toast megjelenitese
			Toast.makeText(
					context, 
					"Hivas felugyelo!\n Uj kimeno hivas a kovetkezo szamra: " + phoneNumber, 
					Toast.LENGTH_LONG).show();
	
		}
	}

	
	
	