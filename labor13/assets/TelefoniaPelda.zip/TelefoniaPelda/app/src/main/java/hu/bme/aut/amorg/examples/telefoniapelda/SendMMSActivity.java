package hu.bme.aut.amorg.examples.telefoniapelda;

import java.io.File;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SendMMSActivity extends Activity {

	EditText phoneNumberTxt, messageTextTxt;
	Button sendMmsBtn, attachFileBtn;
	TextView attachedFileTxt;
	
	final int REQUEST_PICKFILE = 1;
	
	File attachedFile = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_send_mms);
		
		setupUIReferences();
		
		// fajl csatolas 
		attachFileBtn.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				// fajl valasztas Implicit Intent
				Intent pickFile = new Intent();
				pickFile.setAction(Intent.ACTION_GET_CONTENT);
				pickFile.setType("file/*");
				startActivityForResult(pickFile, REQUEST_PICKFILE);
			}
		});
		
		// MMS kuldes
		sendMmsBtn.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				
				String phoneNumber = phoneNumberTxt.getText().toString();
				String messageText = messageTextTxt.getText().toString();
				
				Uri attachedFileUri = null;
				if(attachedFile != null)
					attachedFileUri = Uri.fromFile(attachedFile);
				
				Intent sendMMSIntent = new Intent();
				sendMMSIntent.setAction(Intent.ACTION_SEND);
				
				sendMMSIntent.putExtra("address", phoneNumber);
				
				sendMMSIntent.putExtra("sms_body", messageText);
				
				if(attachedFileUri != null){
					sendMMSIntent.setData(attachedFileUri);
					sendMMSIntent.putExtra(Intent.EXTRA_STREAM, attachedFileUri);
					
					// MIME tipus kideritese
					String mimeType = null;
				    String extension = MimeTypeMap.getFileExtensionFromUrl(attachedFile.getName());
				    if (extension != null) {
				        mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
				    }
				    Log.v("MMS", "Mime type: " + mimeType);
				    sendMMSIntent.setType(mimeType);
				    
				    try{
				    	startActivity(sendMMSIntent);
				    }
				    catch(ActivityNotFoundException e){
				    	Toast.makeText(
				    			getApplicationContext(), 
				    			"Nincs MMS küldésre alkalmas szoftver!", 
				    			Toast.LENGTH_LONG).show();
				    }
				}
			}
		});
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode == Activity.RESULT_CANCELED)
			return;
		
		switch(requestCode){
			// Kivalasztott file csatolasa 
			case REQUEST_PICKFILE:
				String filePath = data.getDataString();
				attachedFile = new File(filePath);
				attachedFileTxt.setText(attachedFile.getName());
				break;
			default: break;
		}
	}

	private void setupUIReferences() {
		phoneNumberTxt = (EditText) findViewById(R.id.phoneNumber);
		messageTextTxt = (EditText) findViewById(R.id.messageText);
		sendMmsBtn = (Button) findViewById(R.id.sendMms);
		attachFileBtn = (Button) findViewById(R.id.attachFile);
		attachedFileTxt = (TextView) findViewById(R.id.attachedFile);
	}
	
	
}
