package hu.bme.aut.amorg.examples.telefoniapelda;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.widget.Toast;

	public class IncomingCallReceiver extends BroadcastReceiver {
	
		@Override
		public void onReceive(Context context, Intent intent) {
			
			Bundle extras = intent.getExtras();
			
			// null vizsgalat
			if(extras == null)
				return;
			
			String callState = extras.getString(TelephonyManager.EXTRA_STATE);
			
			// minket most csak a bejovo hivas erdekel
			if(callState.equalsIgnoreCase(TelephonyManager.EXTRA_STATE_RINGING)){
				// hivo telefonszam
				String incomingNumber = extras.getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
				// Toast megjelenitese
				Toast.makeText(
						context, 
						"Hivas felugyelo!\n Uj bejovo hivas a kovetkezo telefonszamrol: " + incomingNumber, 
						Toast.LENGTH_LONG).show();
			}
			// opcionalis: tovabbi allapotvaltasok lekezelese
			// (EXTRA_STATE_IDLE, EXTRA_STATE_OFFHOOK)
		}
	}

	
	
	