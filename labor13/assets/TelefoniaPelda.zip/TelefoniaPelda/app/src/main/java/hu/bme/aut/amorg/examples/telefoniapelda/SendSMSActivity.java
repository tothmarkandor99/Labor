package hu.bme.aut.amorg.examples.telefoniapelda;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SendSMSActivity extends Activity {
	
	EditText phoneNumberTxt, messageTextTxt;
	Button sendIntentBtn, sendProgBtn;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_send_sms);
		
		setupUIReferences();
		
		sendIntentBtn.setOnClickListener(sendSms);
		sendProgBtn.setOnClickListener(sendSms);
	}
	
	
	// kozos esemenykezelo a ket SMS kuldo gombhoz
	OnClickListener sendSms = new OnClickListener() {
		
		public void onClick(View v) {
			
			String phoneNumber = phoneNumberTxt.getText().toString();
			String messageText = messageTextTxt.getText().toString();
			
			switch(v.getId()){
			
				case R.id.sendIntent:
					
					
					// SMS kuldese Implicit Intent-el
					Intent sendSmsIntent = new Intent();
					
					// akcio: ACTION_SENDTO
					sendSmsIntent.setAction(Intent.ACTION_SENDTO);
					
					// adat = Uri.parse(sms:[telefonszam])
					sendSmsIntent.setData(Uri.parse("sms:" + phoneNumber));
					
					// SMS szovege intent extra-kent kerul be
					sendSmsIntent.putExtra("sms_body", messageText);
					
					// intent inditasa
					try{
						startActivity(sendSmsIntent);
					}
					catch (ActivityNotFoundException e) {
						Toast.makeText(
								getApplicationContext(), 
								"Nincs SMS küldő alkalamzás!", 
								Toast.LENGTH_LONG).show();
					}
					
					break;
					
				case R.id.sendProg:
					// SMS kuldese programozottan
					SmsManager smsManager = SmsManager.getDefault();
					smsManager.sendTextMessage(
							phoneNumber, // cimzett telefonszam 
							null, // SMS szolgaltatokozpont telefonszama, null = default
							messageText, // uzenet szovege
							null, // opcionalis PendingIntent az uzenet elkuldesere
							null); // opcionalis PendingIntent az uzenet kezbesitesere
					Toast.makeText(getApplicationContext(), "SMS küldés megkezdve", Toast.LENGTH_SHORT).show();
					break;
			}
			
		}
	};

	private void setupUIReferences() {
		phoneNumberTxt = (EditText) findViewById(R.id.phoneNumber);
		messageTextTxt = (EditText) findViewById(R.id.messageText);
		sendIntentBtn = (Button) findViewById(R.id.sendIntent);
		sendProgBtn = (Button) findViewById(R.id.sendProg);
	}

}
