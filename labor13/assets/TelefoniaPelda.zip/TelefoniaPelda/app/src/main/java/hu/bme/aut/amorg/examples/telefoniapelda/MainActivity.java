package hu.bme.aut.amorg.examples.telefoniapelda;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.CellLocation;
import android.telephony.NeighboringCellInfo;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class MainActivity extends Activity {

	Button callPhoneBtn, dialPhoneBtn, gotoSmsActivityBtn, gotoMmsActivityBtn;
	TextView telephonyLog;
	EditText phoneNumber;
	ScrollView scrollView;

	TelephonyManager telephonyManager;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// UI elemek referenciainak lekerese (kulon metodusban, hogy itt ne foglalja a helyet)
		setupUIReferences();

		// UI esemenykezelok bekotese (OnClickListener, ...)
		setupUIListeners();

        /* ************************************************** */
        /* ************ TELEFONIA *************************** */

		// 1: TelephonyManager referencia
		telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

		// 2: PhoneStateListener implementacio (eleg hosszu, ezert kulon fuggvenybe kerult)
		PhoneStateListener phoneStateListener = setupPhoneStateListener();

		// 3: Telefonia esemenykezelok bekotese
		telephonyManager.listen(phoneStateListener,
				PhoneStateListener.LISTEN_CALL_STATE | // nem szamit a sorrend
						PhoneStateListener.LISTEN_SIGNAL_STRENGTHS |
						PhoneStateListener.LISTEN_CALL_FORWARDING_INDICATOR |
						PhoneStateListener.LISTEN_CELL_LOCATION |
						PhoneStateListener.LISTEN_DATA_ACTIVITY |
						PhoneStateListener.LISTEN_DATA_CONNECTION_STATE |
						PhoneStateListener.LISTEN_MESSAGE_WAITING_INDICATOR |
						PhoneStateListener.LISTEN_SERVICE_STATE
		);

		// TelephonyManager-tol kozvetlenul lekerdezheto peldaul a SIM kartya allapota.
		switch (telephonyManager.getSimState()) {

			case TelephonyManager.SIM_STATE_ABSENT:
				writeLog("Nincs SIM kurtya a kuszulukben");
				break;

			case TelephonyManager.SIM_STATE_NETWORK_LOCKED:
				writeLog("A mobilszolgaltato letiltotta a kartyat");
				break;

			case TelephonyManager.SIM_STATE_PIN_REQUIRED:
				writeLog("PIN kod megadasa szukseges, csak segelyhivasok");
				break;

			case TelephonyManager.SIM_STATE_PUK_REQUIRED:
				writeLog("PUK kod megadasa szukseges, csak segelyhivasok");
				break;

			case TelephonyManager.SIM_STATE_READY:
				writeLog("A SIM kartya hasznalhato hivas inditasra es fogadasra");
				break;

			case TelephonyManager.SIM_STATE_UNKNOWN:
				writeLog("A kartya allapota nem meghatarozhato");
				break;
		}

		// Roaming
		if(telephonyManager.isNetworkRoaming())
			writeLog("Roaming aktiv, kulfoldi halozat");
		else
			writeLog("Otthoni halozat");

		// Aktualis szolgaltato neve
		writeLog("Szolgaltato neve: "+telephonyManager.getNetworkOperatorName());

		// Aktualis szolgaltato kodja (MCC + MNC)
		writeLog("Szolgaltato kudja: "+telephonyManager.getNetworkOperator());

		// Hivas allapot
		switch(telephonyManager.getCallState()){
			case TelephonyManager.CALL_STATE_RINGING:
				writeLog("uj bejovo hivas (csurug a telefon)");
				// a hivo szam igy nem kerdezheto le, csak esemenykezelovel!
				break;

			case TelephonyManager.CALL_STATE_OFFHOOK:
				writeLog("Egy vagy tobb hivas van folyamatban, lehet tarcsazas kozben, kapcsolodva vagy tartasban.");
				break;

			case TelephonyManager.CALL_STATE_IDLE:
				writeLog("Nincs aktivitas a mobilhalozaton");
				break;
		}

		// Telefonalasra alkalmas modul tipusa + eszkoz azonosito (IMEI / MEID)
		switch(telephonyManager.getPhoneType()){
			case TelephonyManager.PHONE_TYPE_GSM:
				writeLog("IMEI: " + telephonyManager.getDeviceId());
				break;

			case TelephonyManager.PHONE_TYPE_CDMA:
				writeLog("MEID: " + telephonyManager.getDeviceId());
				break;

			case TelephonyManager.PHONE_TYPE_SIP:
				writeLog("SIP radio azonositoja: " + telephonyManager.getDeviceId());
				break;

			case TelephonyManager.PHONE_TYPE_NONE:
				writeLog("Az eszkozben nincs telefonulusra alkalmas modul");
				break;

			default:
				writeLog("Ismeretlen telefon modul tupus: " + telephonyManager.getPhoneType());
				break;
		}

		int dataState = telephonyManager.getDataState();
		int dataActivity = telephonyManager.getDataActivity();

		CellLocation cellLocation = telephonyManager.getCellLocation();
		printNeighboringCells();

		int simState = telephonyManager.getSimState();

		writeLog("SIM kartya szeriaszuma: " + telephonyManager.getSimSerialNumber());

		writeLog("SIM szolgaltato neve: " + telephonyManager.getSimOperatorName());
		writeLog("SIM szolgaltato kudja (MCC+MNC): " + telephonyManager.getSimOperator());

		writeLog("Sajut telefonszam: " + telephonyManager.getLine1Number());

		writeLog("Hangposta telefonszama: " + telephonyManager.getVoiceMailNumber());
	}


	/* Sajat PhoneStateListner */
	private PhoneStateListener setupPhoneStateListener() {

		// Ne felejtsuk el elkerni a kovetkezo permission-oket:
		// - READ_PHONE
		// - ACCESS_COARSE_LOCATION (onCellLocationChanged-hez)

		PhoneStateListener psl = new PhoneStateListener() {

			@Override
			public void onServiceStateChanged(ServiceState serviceState) {
				// Otthoni vagy kulfoldi halozaton vagyunk
				boolean isRoaming = serviceState.getRoaming();
				if(isRoaming)
					writeLog("Roaming aktiv");
				else
					writeLog("Roaming inaktiv");

				// Halozat valasztas modjanak aktualis beallitasa
				boolean networkSelectionMode = serviceState.getIsManualSelection();
				if (networkSelectionMode == true) {
					writeLog("Kezi halozatvalsztas van beallitva");
				} else {
					writeLog("Automatikus halozatvalsztas van beallitva");
				}

				// szolgaltato hosszu es rovid neve
				String operatorNameLong = serviceState.getOperatorAlphaLong();
				writeLog("Aktualis mobilhalozat szolgaltatojanak hosszu neve: " + operatorNameLong);
				String operatorNameShort = serviceState.getOperatorAlphaShort();
				writeLog("Aktualis mobilhalozat szolgaltatojanak rovid neve: " + operatorNameShort);

				// Aktualis mobilhalozat szolgaltatojanak numerikus kodja:
				// orszagkod (pontosan 3 szamjegy, Magyarorszag eseten 216)
				// +
				// operator kod (2 vagy 3 szamjegy, elohivoszam, 20/30/70)
				//
				// peldaul: 21630 (Telekom), 21620 (Telenor), 21670 (Vodafone)
				String operatorCode = serviceState.getOperatorNumeric();
				writeLog("Aktualis mobilhalozat szolgaltatojanak kodja (MCC+MNC): " + operatorCode);

				switch (serviceState.getState()) {

					case ServiceState.STATE_EMERGENCY_ONLY:
						// Csak veszhivasok engedelyezettek (112, 911)
						writeLog("Kapcsolodva a mobilhalozathoz, de a SIM kartya le van zarva");
						break;

					case ServiceState.STATE_IN_SERVICE:
						// Minden hivas engedelyezett
						writeLog("Kapcsolodva a mobilhalozathoz, SIM kartya feloldva");
						break;

					case ServiceState.STATE_OUT_OF_SERVICE:
						writeLog("Nincs kapcsolat a mobilhalozattal");
						// A kovetkezo esetekben fordulhat elo:
						// A telefon epp keresi a szolgaltatot ahova regisztralhat
						// Egyaltalan nem keres szolgaltatot
						// A kivalasztott szolgaltato visszautasitotta a
						// regisztracios kerest
						// Nincs jel a mobilhalozatrol
						break;

					case ServiceState.STATE_POWER_OFF:
						writeLog("Mobilhalozati modul kikapcsolva");
						// Jellemzoen "Repulogep uzemmod" eseten
						break;
				}
			}


			@Override
			public void onCallForwardingIndicatorChanged(boolean isForwarding) {
				super.onCallForwardingIndicatorChanged(isForwarding);

				if (isForwarding) {
					writeLog("Hivas atiranyitas bekapcsolva");

				} else {
					writeLog("Hivas atiranyitas kikapcsolva");
				}
			}

			@Override
			public void onCallStateChanged(int state, String incomingNumber) {
				super.onCallStateChanged(state, incomingNumber);

				switch (state) {
					case TelephonyManager.CALL_STATE_RINGING:
						writeLog("uj bejovo hivas");
						writeLog("A hivo telefonszama: " + incomingNumber);
						break;

					case TelephonyManager.CALL_STATE_OFFHOOK:
						writeLog("Egy vagy tobb hivas van folyamatban, lehet tarcsazas kozben, kapcsolodva vagy tartasban.");
						break;

					case TelephonyManager.CALL_STATE_IDLE:
						writeLog("Nincs aktivitas a mobilhalozaton");
						break;

				}
			}

			@Override
			public void onDataActivity(int direction) {
				super.onDataActivity(direction);

				switch (direction) {
					case TelephonyManager.DATA_ACTIVITY_IN:
						writeLog("Letoltes zajlik");
						break;

					case TelephonyManager.DATA_ACTIVITY_OUT:
						writeLog("Feltoltes zajlik");
						break;

					case TelephonyManager.DATA_ACTIVITY_INOUT:
						writeLog("Mindket iranyban tortenik adatforgalom");
						break;

					case TelephonyManager.DATA_ACTIVITY_NONE:
						writeLog("Nincs adatforgalom");
						break;

					case TelephonyManager.DATA_ACTIVITY_DORMANT:
						writeLog("Aktiv adatforgalom, de a fizikai kapcsolat megszakadt");
						break;
				}
			}

			@Override
			public void onDataConnectionStateChanged(int newState) {
				super.onDataConnectionStateChanged(newState);

				switch (newState) {
					case TelephonyManager.DATA_CONNECTING:
						writeLog("Mobilnet csatlakozas folyamatban");
						break;

					case TelephonyManager.DATA_CONNECTED:
						writeLog("Mobilnet kapcsolodva");
						break;

					case TelephonyManager.DATA_SUSPENDED:
						writeLog("A kapcsolat felfuggesztve");
						break;

					case TelephonyManager.DATA_DISCONNECTED:
						writeLog("Nincs mobilnet kapcsolat");
						break;

				}
			}

			@Override
			public void onMessageWaitingIndicatorChanged(boolean isNewMessage) {
				super.onMessageWaitingIndicatorChanged(isNewMessage);

				if (isNewMessage) {
					writeLog("Van uj hangposta uzenet");
				} else {
					writeLog("Nincs uj hangposta uzenet");
				}
			}

			@Override
			public void onCellLocationChanged(CellLocation location) {
				super.onCellLocationChanged(location);

				//kasztolas GsmLocation objektumma
				// TODO: ha CDMA halozat, akkor CdmaCellLocation legyen!
				GsmCellLocation gsmCellLocation = (GsmCellLocation) location;

				int cellId = gsmCellLocation.getCid();
				writeLog("uj cella azonosito: " + cellId);

				int locationAreaCode = gsmCellLocation.getLac();
				writeLog("uj terulet azonosito: " + locationAreaCode);

				printNeighboringCells();
			}

			@Override
			public void onSignalStrengthsChanged(SignalStrength signalStrength) {

				// GSM halozat hiba rataja (TS 27.007 8.5 szabvany szerint)
				// 0-7 kozti ertek
				int gsmErrorRate = signalStrength.getGsmBitErrorRate();
				if(gsmErrorRate > 0)
					writeLog("GSM halozat hiba rataja: " + gsmErrorRate + "/7");

				// GSM jelerosseg (TS 27.007 8.5 szabvany szerint)
				// 0-31 kozti ertek
				int gsmSignal = signalStrength.getGsmSignalStrength();
				if(gsmSignal > 0)
					writeLog("GSM jelerosseg: " + gsmSignal + "/31");

				// CDMA halozat eseten az RSSI ertek dBm-ben
				int cdmaRSSI = signalStrength.getCdmaDbm();
				if(cdmaRSSI > 0)
					writeLog("CDMA halozat eseten az RSSI ertek dBm-ben: " + cdmaRSSI);

				// CDMA halozat eseten az Ec/Io ertek, dB*10
				int cdmaEcIo = signalStrength.getCdmaEcio();
				if(cdmaEcIo > 0)
					writeLog("CDMA halozat eseten az Ec/Io ertek, dB*10: " + cdmaEcIo);

				// EVDO halozat eseten az RSSI ertek dBm-ben
				// (ez a halozat tipus csak az USA-ban hasznalt)
				int evdoRSSI = signalStrength.getEvdoDbm();
				if(evdoRSSI > 0)
					writeLog("EVDO halozat eseten az RSSI ertek dBm-ben: " + evdoRSSI);

				// EVDO halozat eseten az Ec/Io ertek, dB*10
				// (ez a halozat tipus csak az USA-ban hasznalt)
				int evdoEcIo = signalStrength.getEvdoEcio();
				if(evdoEcIo > 0)
					writeLog("EVDO halozat eseten az Ec/Io ertek, dB*10: " + evdoEcIo);

				// EVDO halozat eseten a jel-zaj arany
				// erteke 0-8 lehet, 8 a legnagyobb SNR
				// (ez a halozat tipus csak az USA-ban hasznalt)
				int evdoSNR = signalStrength.getEvdoSnr();
				if(evdoSNR > 0)
					writeLog("EVDO halozat eseten a jel-zaj arany: " + evdoSNR);
			}

		};
		return psl;
	}

	private void writeLog(String msg){
		SimpleDateFormat myDateFormat = new SimpleDateFormat("HH:mm:ss");
		telephonyLog.append("["+myDateFormat.format(new Date())+"] "+msg+"\n");

		// log ablak aljara ugrik
		scrollView.post(new Runnable() {

			public void run() {
				scrollView.fullScroll(ScrollView.FOCUS_DOWN);
			}
		});
	}

	private void printNeighboringCells() {
		List<NeighboringCellInfo> cells = telephonyManager.getNeighboringCellInfo();

		writeLog("Szomszedos cellak\n----------------------------");
		for(NeighboringCellInfo cellInfo : cells){
			// TODO szomszedos cellak adatainak feldolgozasa

			writeLog("Cell ID: " + cellInfo.getCid());
			writeLog("LAC: " + cellInfo.getLac());
			writeLog("Halozat tipus konstans: " + cellInfo.getNetworkType());
			writeLog("----------------------------");
		}
	}

	private void setupUIListeners() {
		// a telefonszam feldolgozo gombokra ugyanazt az esemenykezelot kotjuk be
		// majd ott eldontjuk hogy mit kell csinalni a telefonszammal
		callPhoneBtn.setOnClickListener(callPhoneClick);
		dialPhoneBtn.setOnClickListener(callPhoneClick);

		// SMS kuldes Activity-re valtas
		gotoSmsActivityBtn.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				Intent i = new Intent(getApplicationContext(), SendSMSActivity.class);
				startActivity(i);
			}
		});

		// MMS kuldes Activity-re valtas
		gotoMmsActivityBtn.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				Intent i = new Intent(getApplicationContext(), SendMMSActivity.class);
				startActivity(i);
			}
		});

		// a callPhone es dialPhone gombokat csak akkor aktivaljuk, ha a telefonszam mezo nem ures
		phoneNumber.addTextChangedListener(new TextWatcher() {

			public void onTextChanged(CharSequence s, int start, int before, int count) { }

			public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

			public void afterTextChanged(Editable s) {
				if(s.length()>0){
					callPhoneBtn.setEnabled(true);
					dialPhoneBtn.setEnabled(true);
				}
				else{
					callPhoneBtn.setEnabled(false);
					dialPhoneBtn.setEnabled(false);
				}

			}
		});
	}

	OnClickListener callPhoneClick = new OnClickListener() {

		public void onClick(View v) {

			// phoneNumber EditText-ben megadott telefonszam tarcsazasa vagy felhivasa
			String phoneNo = phoneNumber.getText().toString();
			Intent i = new Intent();
			// Data URI beallitasa: 'tel:[telefonszam]'
			i.setData(Uri.parse("tel:" + phoneNo));

			// hivas vagy tarcsazas attol fuggoen, hogy
			// melyik gomb megnyomasara fut le ez a callback
			switch (v.getId()) {
				case R.id.callPhoneBtn:
					// ehhez kell a CALL_PHONE permission!
					i.setAction(Intent.ACTION_CALL);
					break;
				case R.id.dialPhoneBtn:
					i.setAction(Intent.ACTION_DIAL);
					break;
				default:
					break;
			}
			// hivas vagy tarcsazas kezdemenyezese a mar osszeallitott implicit intent-el
			try{
				startActivity(i);
			}
			catch (ActivityNotFoundException e) {
				Toast.makeText(
						getApplicationContext(),
						"Nincs telepítve tárcsázó alkalmazás!",
						Toast.LENGTH_SHORT).show();
			}
		}
	};

	private void setupUIReferences() {
		callPhoneBtn = (Button) findViewById(R.id.callPhoneBtn);
		dialPhoneBtn = (Button) findViewById(R.id.dialPhoneBtn);
		gotoSmsActivityBtn = (Button) findViewById(R.id.gotoSmsActivity);
		gotoMmsActivityBtn = (Button) findViewById(R.id.gotoMmsActivity);

		telephonyLog = (TextView) findViewById(R.id.telephonyLog);

		phoneNumber = (EditText) findViewById(R.id.phoneNumber);

		scrollView = (ScrollView) findViewById(R.id.scrollView);
	}
}