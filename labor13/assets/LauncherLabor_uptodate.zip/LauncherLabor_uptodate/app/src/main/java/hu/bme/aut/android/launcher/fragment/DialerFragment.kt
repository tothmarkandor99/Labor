package hu.bme.aut.android.launcher.fragment


import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import hu.bme.aut.android.launcher.R
import kotlinx.android.synthetic.main.fragment_dialer.*


class DialerFragment : Fragment() {

    private val clickListener = View.OnClickListener { view ->
        val valueToAppend = when (view.id) {
            R.id.btnDialer0 -> "0"
            R.id.btnDialer1 -> "1"
            R.id.btnDialer2 -> "2"
            R.id.btnDialer3 -> "3"
            R.id.btnDialer4 -> "4"
            R.id.btnDialer5 -> "5"
            R.id.btnDialer6 -> "6"
            R.id.btnDialer7 -> "7"
            R.id.btnDialer8 -> "8"
            R.id.btnDialer9 -> "9"
            R.id.btnDialerStar -> "*"
            R.id.btnDialerHashmark -> "#"
            else -> null
        }

        if (valueToAppend != null) {
            etCall.append(valueToAppend)
        } else if (etCall.text.isNotEmpty()) {
            val length = etCall.text.length
            etCall.text.delete(length - 1, length)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_dialer, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val buttons = listOf(
                btnDialer0,
                btnDialer1,
                btnDialer2,
                btnDialer3,
                btnDialer4,
                btnDialer5,
                btnDialer6,
                btnDialer7,
                btnDialer8,
                btnDialer9,
                btnDialerStar,
                btnDialerHashmark,
                btnCallBackSpace
        )

        buttons.forEach {
            it.setOnClickListener(clickListener)
        }

        btnCall.setOnClickListener {
            val phoneNumber = "tel:${etCall.text}"
            val intent = Intent(
                    Intent.ACTION_CALL,
                    Uri.parse(phoneNumber)
            )
            requireContext().startActivity(intent)
        }
    }

}
