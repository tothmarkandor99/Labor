package hu.bme.aut.android.launcher.adapter

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import hu.bme.aut.android.launcher.fragment.ApplicationsFragment
import hu.bme.aut.android.launcher.fragment.CallLogFragment
import hu.bme.aut.android.launcher.fragment.DialerFragment
import hu.bme.aut.android.launcher.fragment.FavoritesFragment


class LauncherPagerAdapter(manager: FragmentManager) : FragmentStatePagerAdapter(manager) {

    companion object {
        private const val NUM_PAGES = 4
    }

    override fun getCount(): Int = NUM_PAGES

    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> DialerFragment()
            1 -> CallLogFragment()
            2 -> FavoritesFragment()
            3 -> ApplicationsFragment()
            else -> throw IllegalArgumentException("No such page!")
        }
    }

}
