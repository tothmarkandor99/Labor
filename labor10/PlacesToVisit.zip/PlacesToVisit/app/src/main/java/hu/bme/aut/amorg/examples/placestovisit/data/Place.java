package hu.bme.aut.amorg.examples.placestovisit.data;

import com.orm.SugarRecord;

import java.io.Serializable;
import java.util.Date;

import hu.bme.aut.amorg.examples.placestovisit.R;

/**
 * Created by Mastre on 2016.11.09..
 */
public class Place extends SugarRecord implements Serializable {

    public Place() {
    }

    public enum PlaceType {
        LANDSCAPE(0, R.drawable.landscape),
        CITY(1, R.drawable.city),
        BUILDING(2, R.drawable.building);

        private int value;
        private int iconId;

        private PlaceType(int value, int iconId) {
            this.value = value;
            this.iconId = iconId;
        }

        public static PlaceType fromInt(int value) {
            for (PlaceType p : PlaceType.values()) {
                if (p.value == value) {
                    return p;
                }
            }
            return LANDSCAPE;
        }

        public int getIconId() {
            return iconId;
        }

        public int getValue() {
            return value;
        }
    }

    private PlaceType placeType;
    private String placeName;
    private String description;
    private Date pickUpDate;

    public Place(PlaceType placeType, String placeName, String description, Date pickUpDate) {
        this.placeType = placeType;
        this.placeName = placeName;
        this.description = description;
        this.pickUpDate = pickUpDate;
    }

    public String getPlaceName() {
        return placeName;
    }

    public String getDescription() {
        return description;
    }

    public Date getPickUpDate() {
        return pickUpDate;
    }

    public PlaceType getPlaceType() {
        return placeType;
    }

    public void setPlaceType(PlaceType placeType) {
        this.placeType = placeType;
    }

    public void setPlaceName(String placeName) {
        this.placeName = placeName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPickUpDate(Date pickUpDate) {
        this.pickUpDate = pickUpDate;
    }
}
