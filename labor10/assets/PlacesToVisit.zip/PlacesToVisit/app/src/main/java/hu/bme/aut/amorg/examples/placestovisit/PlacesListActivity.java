package hu.bme.aut.amorg.examples.placestovisit;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.List;

import hu.bme.aut.amorg.examples.placestovisit.adapter.PlacesToVisitAdapter;
import hu.bme.aut.amorg.examples.placestovisit.data.Place;

public class PlacesListActivity extends AppCompatActivity {

    public static final int REQUEST_NEW_PLACE_CODE = 100;
    public static final int REQUEST_EDIT_PLACE_CODE = 101;

    private RecyclerView recyclerView;
    private PlacesToVisitAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        List<Place> placesToVisit = Place.listAll(Place.class);

        recyclerView = (RecyclerView) findViewById(R.id.placesListRV);
        adapter = new PlacesToVisitAdapter(this, placesToVisit);
        recyclerView.setLayoutManager(new LinearLayoutManager((this)));
        recyclerView.setAdapter(adapter);

        registerForContextMenu(recyclerView);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (resultCode) {
            case RESULT_OK:
                if (requestCode == REQUEST_NEW_PLACE_CODE) {
                    Place place = (Place) data.getSerializableExtra(
                            CreatePlaceToVisitActivity.KEY_PLACE);
                    // when I call the save() function
                    // it will generate the id for the place
                    place.save();

                    adapter.addPlace(place);
                    adapter.notifyDataSetChanged();
                    Toast.makeText(this, R.string.added, Toast.LENGTH_LONG).show();
                } else if (requestCode == REQUEST_EDIT_PLACE_CODE) {
                    int index = data.getIntExtra(CreatePlaceToVisitActivity.KEY_EDIT_ID, -1);
                    if (index != -1) {
                        Place place = (Place) data.getSerializableExtra(
                                CreatePlaceToVisitActivity.KEY_PLACE);
                        place.setId(adapter.getItem(index).getId());
                        place.save();


                        adapter.updatePlace(
                                index,
                                (Place) data.getSerializableExtra(
                                        CreatePlaceToVisitActivity.KEY_PLACE));
                        adapter.notifyDataSetChanged();
                        Toast.makeText(this, R.string.updated, Toast.LENGTH_LONG).show();
                    }
                }
                break;
            case RESULT_CANCELED:
                Toast.makeText(this, R.string.cancelled, Toast.LENGTH_LONG).show();
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_places_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_new_place) {
            showNewPlaceDialog();

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showNewPlaceDialog() {
        Intent i = new Intent();
        i.setClass(this, CreatePlaceToVisitActivity.class);
        startActivityForResult(i, REQUEST_NEW_PLACE_CODE);
    }

}
