package hu.bme.aut.android.spaceshipgame

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import hu.bme.aut.android.spaceshipgame.R

class GameActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)
    }
}
