package hu.bme.aut.amorg.example.spaceshipgame.rendering;

import android.content.Context;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class GameView extends SurfaceView {

	public GameView(Context context) {
		super(context);
		init();
	}

	public GameView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public GameView(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs,defStyleAttr);
		init();
	}

	private void init() {
		SurfaceHolder holder = getHolder();
		holder.addCallback(new SurfaceHolder.Callback() {
			@Override
			public void surfaceCreated(SurfaceHolder holder) {
				//TODO: Start rendering
			}

			@Override
			public void surfaceDestroyed(SurfaceHolder holder) {
				//TODO: Stop rendering
			}

			@Override
			public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
				//TODO: Resize
			}
		});
	}
}
