package hu.bme.aut.amorg.example.spaceshipgame;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import hu.bme.aut.amorg.example.spaceshipgame.rendering.GameView;

public class GameActivity extends AppCompatActivity {

	private GameView gameView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game);
		gameView = (GameView) findViewById(R.id.gameView);
	}
}
