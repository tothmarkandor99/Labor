package hu.bme.aut.amorg.example.spaceshipgame.model;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;

public abstract class Ship implements Renderable {
    protected int spriteHeight;
    protected int spriteWidth;

    protected Bitmap image;
    protected int posX;
    protected int posY;

    public int state = 0;

    protected int screenWidth=0;
    protected int screenHeight=0;


    protected float elevation =0;

    public Ship(Context context) {
        posX = screenWidth;
        posY = screenHeight;
    }

    @Override
    public void step() {
        if (state < 9) {
            state++;
        } else {
            state = 0;
        }
    }

    @Override
    public void size(int x, int y) {
        this.screenWidth = x;
        this.screenHeight = y;
    }

    @Override
    public void render(Canvas canvas) {
        setSpriteSizes();

        int x = 0;
        int y = 0;

        Rect src = new Rect(x, y, x + spriteWidth, y + spriteHeight);
        Rect dst = new Rect(posX, posY, posX + spriteWidth * 4, posY + spriteHeight * 4);


        if(image!=null && canvas!=null)
        {
            canvas.drawBitmap(image, src, dst, null);
        }


    }

    protected abstract void setSpriteSizes();

    public void setElevation(float elevation) {
        this.elevation = elevation;
    }
}
