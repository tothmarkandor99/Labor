package hu.bme.aut.amorg.example.spaceshipgame.model;

import android.content.Context;
import android.graphics.BitmapFactory;

import java.util.Random;

import hu.bme.aut.amorg.example.spaceshipgame.R;

public class Enemy extends Ship {

    protected static final int SPRITE_HORIZONTAL = 1;
    protected static final int SPRITE_VERTICAL = 6;
    public static final int SPEED = 14;
    private final float randomFloat;

    public Enemy(Context context) {
        super(context);
        image = BitmapFactory.decodeResource(context.getResources(), R.drawable.enemy);
        posX=screenWidth;
        posY=screenHeight;
        Random random=new Random();
        randomFloat=random.nextFloat();
    }


    @Override
    public void step() {
        super.step();
        
        posX=posX- SPEED;
        posY=((int)(screenHeight*randomFloat));
    }

    @Override
    public void size(int x, int y) {
        super.size(x, y);
        posX=x;
    }

    protected void setSpriteSizes()
    {
        spriteWidth = image.getWidth() / SPRITE_HORIZONTAL;
        spriteHeight = image.getHeight() / SPRITE_VERTICAL;
    }

}
