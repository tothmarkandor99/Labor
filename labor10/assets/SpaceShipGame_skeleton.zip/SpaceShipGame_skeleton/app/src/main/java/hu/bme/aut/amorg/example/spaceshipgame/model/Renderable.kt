package hu.bme.aut.amorg.example.spaceshipgame.model

import android.graphics.Canvas

interface Renderable {
    fun step()
    fun size(x: Int, y: Int)
    fun render(canvas: Canvas)
}
