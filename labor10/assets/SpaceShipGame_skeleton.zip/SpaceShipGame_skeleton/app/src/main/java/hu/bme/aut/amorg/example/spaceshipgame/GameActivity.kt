package hu.bme.aut.amorg.example.spaceshipgame

import android.os.Bundle
import android.support.v7.app.AppCompatActivity

import hu.bme.aut.amorg.example.spaceshipgame.rendering.GameView

class GameActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)
    }
}
