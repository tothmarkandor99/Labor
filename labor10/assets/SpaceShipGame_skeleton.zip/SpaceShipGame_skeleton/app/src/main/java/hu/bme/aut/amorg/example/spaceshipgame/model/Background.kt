package hu.bme.aut.amorg.example.spaceshipgame.model

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Shader
import android.graphics.drawable.BitmapDrawable
import hu.bme.aut.amorg.example.spaceshipgame.R

class Background(context: Context) : Renderable {
    private var width: Int = 0
    private var height: Int = 0
    private var bitmapDrawable: BitmapDrawable

    init {
        val image = BitmapFactory.decodeResource(context.resources, R.drawable.background)
        bitmapDrawable = BitmapDrawable(image)
        bitmapDrawable.tileModeX = Shader.TileMode.MIRROR
        bitmapDrawable.tileModeY = Shader.TileMode.MIRROR
    }

    override fun step() {
        //Do nothing
    }

    override fun size(x: Int, y: Int) {
        this.width = x
        this.height = y
        bitmapDrawable.setBounds(0, 0, width, height)
    }

    override fun render(canvas: Canvas) {
        bitmapDrawable.draw(canvas)
    }
}
