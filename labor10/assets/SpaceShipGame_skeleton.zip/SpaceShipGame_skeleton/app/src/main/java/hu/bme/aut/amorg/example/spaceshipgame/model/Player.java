package hu.bme.aut.amorg.example.spaceshipgame.model;

import android.content.Context;
import android.graphics.BitmapFactory;

import hu.bme.aut.amorg.example.spaceshipgame.R;

public class Player extends Ship {

    protected static final int SPRITE_HORIZONTAL = 1;
    protected static final int SPRITE_VERTICAL = 4;

    public Player(Context context) {
        super(context);
        image = BitmapFactory.decodeResource(context.getResources(), R.drawable.ship);
    }

    @Override
    public void step() {
        super.step();
        posX=5;
        posY-=(int)((elevation /10.0f)*(float)screenHeight);
        if(posY>screenHeight)
        {
            posY=screenHeight;
        }
        if(posY<spriteHeight)
        {
            posY=spriteHeight;
        }

    }

    protected void setSpriteSizes()
    {
        spriteWidth = image.getWidth() / SPRITE_HORIZONTAL;
        spriteHeight = image.getHeight() / SPRITE_VERTICAL;
    }

}
