package hu.bme.aut.android.placestovisit.data

import android.arch.persistence.room.Database
import android.arch.persistence.room.RoomDatabase
import android.arch.persistence.room.TypeConverters

import hu.bme.aut.android.placestovisit.data.converters.DateTypeConverter
import hu.bme.aut.android.placestovisit.data.converters.PlaceTypeConverter

@Database(entities = [Place::class], version = 1, exportSchema = false)
@TypeConverters(DateTypeConverter::class, PlaceTypeConverter::class)
abstract class PlaceDatabase : RoomDatabase() {

    abstract fun placeDao(): PlaceDao

}
