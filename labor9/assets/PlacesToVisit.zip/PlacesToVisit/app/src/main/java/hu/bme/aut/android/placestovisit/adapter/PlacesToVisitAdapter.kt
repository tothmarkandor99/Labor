package hu.bme.aut.android.placestovisit.adapter

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.view.ContextMenu
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

import hu.bme.aut.android.placestovisit.CreatePlaceToVisitActivity
import hu.bme.aut.android.placestovisit.PlacesListActivity.Companion.REQUEST_EDIT_PLACE_CODE
import hu.bme.aut.android.placestovisit.R
import hu.bme.aut.android.placestovisit.data.Place
import hu.bme.aut.android.placestovisit.data.PlaceDatabase
import kotlinx.android.synthetic.main.row_place.view.*

class PlacesToVisitAdapter(
        private val context: Context,
        private val database: PlaceDatabase
) : RecyclerView.Adapter<PlacesToVisitAdapter.PlacesViewHolder>() {

    private val placesToVisit: MutableList<Place> = mutableListOf()

    companion object {
        const val CONTEXT_ACTION_DELETE: Int = 10
        const val CONTEXT_ACTION_EDIT: Int = 11
    }

    fun addPlace(place: Place) {
        placesToVisit.add(place)
        notifyItemInserted(placesToVisit.lastIndex)
    }

    fun addPlaces(places: List<Place>) {
        val oldSize = placesToVisit.size
        placesToVisit.addAll(places)
        notifyItemRangeInserted(oldSize, places.size)
    }

    fun updatePlace(index: Int, place: Place) {
        placesToVisit[index] = place
        notifyItemChanged(index)
    }

    fun removePlace(index: Int) {
        placesToVisit.removeAt(index)
        notifyItemRemoved(index)
    }

    fun getItem(i: Int) = placesToVisit[i]

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlacesViewHolder {
        val itemView = LayoutInflater
                .from(parent.context)
                .inflate(R.layout.row_place, parent, false)
        return PlacesViewHolder(itemView)
    }

    private fun sharePlace(place: Place) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "message/rfc822"
            putExtra(Intent.EXTRA_EMAIL, arrayOf("peter.ekler@aut.bme.hu"))
            putExtra(Intent.EXTRA_SUBJECT, "Place info")
            putExtra(Intent.EXTRA_TEXT, "${place.placeName}\n${place.description}")
        }

        try {
            context.startActivity(Intent.createChooser(intent, "Send mail..."))
        } catch (ex: ActivityNotFoundException) {
            Toast.makeText(context, "There are no email clients installed.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBindViewHolder(holder: PlacesViewHolder, position: Int) {
        val place = placesToVisit[position]

        holder.run {
            tvPlace.text = place.placeName
            tvDescription.text = place.description
            tvDate.text = place.creationDate.toString()
            ivIcon.setImageResource(place.placeType.iconId)

            btnEmail.setOnClickListener {
                sharePlace(place)
            }
        }
    }

    override fun getItemCount(): Int {
        return placesToVisit.size
    }

    inner class PlacesViewHolder(itemView: View)
        : RecyclerView.ViewHolder(itemView), View.OnCreateContextMenuListener, MenuItem.OnMenuItemClickListener {

        val tvPlace: TextView = itemView.tvPlace
        val tvDescription: TextView = itemView.tvDescription
        val tvDate: TextView = itemView.tvDate
        val ivIcon: ImageView = itemView.ivIcon
        val btnEmail: ImageButton = itemView.btnEmail

        init {
            itemView.setOnCreateContextMenuListener(this)
        }

        override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenu.ContextMenuInfo?) {
            menu.setHeaderTitle("Menu")

            val item1 = menu.add(0, CONTEXT_ACTION_DELETE, 0, "Delete")
            item1.setOnMenuItemClickListener(this)

            val item2 = menu.add(0, CONTEXT_ACTION_EDIT, 0, "Edit")
            item2.setOnMenuItemClickListener(this)
        }

        override fun onMenuItemClick(item: MenuItem): Boolean {
            when (item.itemId) {
                CONTEXT_ACTION_DELETE -> {
                    val place = getItem(adapterPosition)
                    val handler = Handler()
                    Thread {
                        database.placeDao().delete(place)
                        handler.post {
                            removePlace(adapterPosition)
                        }
                    }.start()
                }
                CONTEXT_ACTION_EDIT -> {
                    val selectedPlace = getItem(adapterPosition)
                    val intent = Intent().apply {
                        setClass(context, CreatePlaceToVisitActivity::class.java)
                        putExtra(CreatePlaceToVisitActivity.KEY_EDIT_PLACE, selectedPlace)
                        putExtra(CreatePlaceToVisitActivity.KEY_EDIT_POSITION, adapterPosition)
                    }
                    (context as Activity).startActivityForResult(intent, REQUEST_EDIT_PLACE_CODE)
                }
                else -> return false
            }
            return true
        }

    }
}
