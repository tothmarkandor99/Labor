package hu.bme.aut.android.placestovisit

import android.app.Activity
import android.arch.persistence.room.Room
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.Toolbar
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import hu.bme.aut.android.placestovisit.adapter.PlacesToVisitAdapter
import hu.bme.aut.android.placestovisit.data.Place
import hu.bme.aut.android.placestovisit.data.PlaceDatabase
import kotlinx.android.synthetic.main.content_places_list.*

class PlacesListActivity : AppCompatActivity() {

    companion object {
        const val REQUEST_NEW_PLACE_CODE = 100
        const val REQUEST_EDIT_PLACE_CODE = 101
    }

    private lateinit var adapter: PlacesToVisitAdapter
    private lateinit var db: PlaceDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_places_list)
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        db = Room.databaseBuilder(applicationContext, PlaceDatabase::class.java, "place-db").build()

        adapter = PlacesToVisitAdapter(this@PlacesListActivity, db)
        placesListRV.layoutManager = LinearLayoutManager(applicationContext)
        placesListRV.adapter = adapter

        registerForContextMenu(placesListRV)

        Thread {
            val placesToVisit: MutableList<Place> = db.placeDao().getAll().toMutableList()
            runOnUiThread {
                adapter.addPlaces(placesToVisit)
            }
        }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (resultCode) {
            Activity.RESULT_CANCELED -> Toast.makeText(this, R.string.cancelled, Toast.LENGTH_LONG).show()
            Activity.RESULT_OK -> {
                when (requestCode) {
                    REQUEST_NEW_PLACE_CODE -> createPlace(data)
                    REQUEST_EDIT_PLACE_CODE -> editPlace(data)
                }
            }
        }
    }

    private fun createPlace(data: Intent?) {
        data ?: return

        val place = data.getSerializableExtra(CreatePlaceToVisitActivity.KEY_PLACE) as Place

        Thread {
            db.placeDao().insertAll(place)
            runOnUiThread {
                adapter.addPlace(place)
                Toast.makeText(applicationContext, R.string.added, Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun editPlace(data: Intent?) {
        data ?: return

        val index = data.getIntExtra(CreatePlaceToVisitActivity.KEY_EDIT_POSITION, -1)
        if (index >= 0) {
            val place = data.getSerializableExtra(CreatePlaceToVisitActivity.KEY_PLACE) as Place
            place.id = adapter.getItem(index).id

            Thread {
                db.placeDao().updatePlace(place)
                runOnUiThread {
                    adapter.updatePlace(index, place)
                    Toast.makeText(applicationContext, R.string.updated, Toast.LENGTH_LONG).show()
                }
            }.start()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_places_list, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_new_place -> {
                showNewPlaceDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showNewPlaceDialog() {
        val intent = Intent(this, CreatePlaceToVisitActivity::class.java)
        startActivityForResult(intent, REQUEST_NEW_PLACE_CODE)
    }

}
