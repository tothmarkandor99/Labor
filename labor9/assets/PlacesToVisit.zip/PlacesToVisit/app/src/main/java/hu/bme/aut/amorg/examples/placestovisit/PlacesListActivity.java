package hu.bme.aut.amorg.examples.placestovisit;

import android.arch.persistence.room.Room;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.List;

import hu.bme.aut.amorg.examples.placestovisit.adapter.PlacesToVisitAdapter;
import hu.bme.aut.amorg.examples.placestovisit.data.Place;
import hu.bme.aut.amorg.examples.placestovisit.data.PlaceDatabase;

public class PlacesListActivity extends AppCompatActivity {

    public static final int REQUEST_NEW_PLACE_CODE = 100;
    public static final int REQUEST_EDIT_PLACE_CODE = 101;

    private RecyclerView recyclerView;
    private PlacesToVisitAdapter adapter;
    private PlaceDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        db = Room.databaseBuilder(getApplicationContext(), PlaceDatabase.class, "place-db").build();

        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<Place> placesToVisit = db.placeDao().getAll();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        recyclerView = findViewById(R.id.placesListRV);
                        adapter = new PlacesToVisitAdapter(PlacesListActivity.this, db, placesToVisit);
                        recyclerView.setLayoutManager(new LinearLayoutManager((getApplicationContext())));
                        recyclerView.setAdapter(adapter);

                        registerForContextMenu(recyclerView);
                    }
                });


            }
        }).start();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (resultCode) {
            case RESULT_OK:
                if (requestCode == REQUEST_NEW_PLACE_CODE) {
                    final Place place = (Place) data.getSerializableExtra(
                            CreatePlaceToVisitActivity.KEY_PLACE);
                    // when I call the save() function
                    // it will generate the id for the place

                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            db.placeDao().insertAll(place);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    adapter.addPlace(place);
                                    adapter.notifyDataSetChanged();
                                }
                            });
                        }
                    }).start();


                    Toast.makeText(this, R.string.added, Toast.LENGTH_LONG).show();
                } else if (requestCode == REQUEST_EDIT_PLACE_CODE) {
                    final int index = data.getIntExtra(CreatePlaceToVisitActivity.KEY_EDIT_ID, -1);
                    if (index != -1) {
                       final Place place = (Place) data.getSerializableExtra(
                                CreatePlaceToVisitActivity.KEY_PLACE);
                        place.setId(adapter.getItem(index).getId());

                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                db.placeDao().updatePlace(place);

                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        adapter.updatePlace(index,place);
                                        adapter.notifyDataSetChanged();
                                        Toast.makeText(getApplicationContext(), R.string.updated, Toast.LENGTH_LONG).show();
                                    }
                                });
                            }
                        }).start();



                    }
                }
                break;
            case RESULT_CANCELED:
                Toast.makeText(this, R.string.cancelled, Toast.LENGTH_LONG).show();
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_places_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_new_place) {
            showNewPlaceDialog();

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showNewPlaceDialog() {
        Intent i = new Intent();
        i.setClass(this, CreatePlaceToVisitActivity.class);
        startActivityForResult(i, REQUEST_NEW_PLACE_CODE);
    }

}
