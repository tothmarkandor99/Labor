package hu.bme.aut.android.placestovisit.data

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import hu.bme.aut.android.placestovisit.R
import java.io.Serializable
import java.util.Date

@Entity
data class Place(
        @PrimaryKey(autoGenerate = true)
        var id: Int = 0,
        @ColumnInfo(name = "place_type")
        var placeType: PlaceType = PlaceType.fromInt(0),
        @ColumnInfo(name = "place_name")
        var placeName: String = "",
        @ColumnInfo(name = "description")
        var description: String = "",
        @ColumnInfo(name = "creation_date")
        var creationDate: Date = Date(0)
) : Serializable {

    enum class PlaceType(val value: Int, val iconId: Int) {
        LANDSCAPE(0, R.drawable.landscape),
        CITY(1, R.drawable.city),
        BUILDING(2, R.drawable.building);

        companion object {
            fun fromInt(value: Int): PlaceType {
                return values().firstOrNull { it.value == value } ?: LANDSCAPE
            }
        }
    }

}
