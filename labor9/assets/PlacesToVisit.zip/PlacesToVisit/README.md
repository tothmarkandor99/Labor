# 9. labor

Branchek:
- `master`: kiinduló projekt a laborhoz
- `feature/lab-exercises`: a labor leírás közös feladatai megoldva
- `feature/extra-exercises`: a labor önálló feladatai megoldva

Ezeket sajnos teljesen manuálisan kell szinkronban tartani, _nagyon_ nehéz merge-elni köztük!!
