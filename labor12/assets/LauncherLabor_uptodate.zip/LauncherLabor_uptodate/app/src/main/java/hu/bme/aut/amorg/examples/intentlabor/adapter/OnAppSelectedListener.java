package hu.bme.aut.amorg.examples.intentlabor.adapter;

import hu.bme.aut.amorg.examples.intentlabor.data.ApplicationInfo;

public interface OnAppSelectedListener {
	void onAppSelected(ApplicationInfo app);
}
