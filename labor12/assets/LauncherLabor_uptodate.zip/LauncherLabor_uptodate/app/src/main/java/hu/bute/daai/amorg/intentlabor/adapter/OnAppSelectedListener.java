package hu.bute.daai.amorg.intentlabor.adapter;

import hu.bute.daai.amorg.intentlabor.data.ApplicationInfo;

public interface OnAppSelectedListener {
	void onAppSelected(ApplicationInfo app);
}
