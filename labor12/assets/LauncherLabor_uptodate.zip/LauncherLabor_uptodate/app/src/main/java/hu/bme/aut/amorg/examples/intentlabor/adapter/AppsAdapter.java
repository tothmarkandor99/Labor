package hu.bme.aut.amorg.examples.intentlabor.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.devspark.robototextview.widget.RobotoTextView;

import java.util.ArrayList;

import hu.bme.aut.amorg.examples.intentlabor.R;
import hu.bme.aut.amorg.examples.intentlabor.data.ApplicationInfo;

public class AppsAdapter extends RecyclerView.Adapter<AppsAdapter.ViewHolder> {
	private final LayoutInflater layoutInflater;
	private final Context context;
	private ArrayList<ApplicationInfo> apps;
	private OnAppSelectedListener listener;

	public AppsAdapter(Context context, ArrayList<ApplicationInfo> apps, OnAppSelectedListener listener) {
		this.apps = apps;
		this.layoutInflater = LayoutInflater.from(context);
		this.context = context;
		this.listener = listener;
	}

	@Override
	public AppsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
		View v = layoutInflater.inflate(R.layout.application, parent, false);
		return new ViewHolder(v);
	}

	@Override
	public void onBindViewHolder(ViewHolder holder, int position) {
		final ApplicationInfo info = apps.get(position);
		Drawable icon = info.getIcon();
		holder.position = position;
		holder.textView.setText(info.getTitle());
		holder.imageView.setImageDrawable(icon);
	}

	@Override
	public int getItemCount() {
		return apps.size();
	}

	public class ViewHolder extends RecyclerView.ViewHolder {
		public ImageView imageView;
		public RobotoTextView textView;
		int position;

		public ViewHolder(View v) {
			super(v);
			imageView = (ImageView) v.findViewById(R.id.icon);
			textView = (RobotoTextView) v.findViewById(R.id.label);
			v.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					if(listener != null){
						listener.onAppSelected(apps.get(position));
					}
				}
			});
		}
	}
}
