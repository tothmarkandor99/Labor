package hu.bme.aut.amorg.examples.intentlabor.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import hu.bme.aut.amorg.examples.intentlabor.R;


public class DialerFragment extends Fragment {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_dialer, container, false);
		final EditText callEditText = (EditText) view.findViewById(R.id.callEditText);

		view.findViewById(R.id.call_button).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				String number = callEditText.getText().toString();
				dialNumber(number);
			}
		});

		return view;
	}

	protected void dialNumber(String number) {
		String phoneNumber = "tel:" + number;
		Intent i = new Intent(
				Intent.ACTION_CALL,
				Uri.parse(phoneNumber)
		);
		startActivity(i);
	}

}
