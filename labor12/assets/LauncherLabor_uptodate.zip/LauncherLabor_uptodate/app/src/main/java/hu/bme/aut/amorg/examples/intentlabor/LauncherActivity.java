package hu.bme.aut.amorg.examples.intentlabor;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;

import hu.bme.aut.amorg.examples.intentlabor.fragments.AppDrawerFragment;
import hu.bme.aut.amorg.examples.intentlabor.fragments.CallLogFragment;
import hu.bme.aut.amorg.examples.intentlabor.fragments.DialerFragment;
import hu.bme.aut.amorg.examples.intentlabor.fragments.FavoritesFragment;


public class LauncherActivity extends FragmentActivity {

	/* Number of views in the viewpager */
	private static final int NUM_PAGES = 4;

	/* The viewpager that is the only view in the xml */
	private ViewPager pager;

	/* Pageradapter, that holds the fragments */
	private PagerAdapter pagerAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_launcher);

    	/* Getting reference to the viewpager, creating new adapter, and setting it to the pager */
		pager = (ViewPager) findViewById(R.id.pager);
		pagerAdapter = new HomeScreenPagerAdapter(getSupportFragmentManager());
		pager.setAdapter(pagerAdapter);
	}

	private class HomeScreenPagerAdapter extends FragmentStatePagerAdapter {

		public HomeScreenPagerAdapter(FragmentManager manager) {
			super(manager);
		}

		@Override
		public Fragment getItem(int position) {
			switch (position){
				case 0: return new DialerFragment();
				case 1: return new CallLogFragment();
				case 2: return new FavoritesFragment();
				case 3: return new AppDrawerFragment();
				default: return new AppDrawerFragment();
			}
		}

		@Override
		public int getCount() {
			return NUM_PAGES;
		}
	}
}
