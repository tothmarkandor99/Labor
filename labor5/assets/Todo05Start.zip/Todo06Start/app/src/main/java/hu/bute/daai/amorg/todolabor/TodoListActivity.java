package hu.bute.daai.amorg.todolabor;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import hu.bute.daai.amorg.todolabor.data.Todo;

/**
 * An activity representing a list of Todos. This activity
 * has different presentations for handset and tablet-size devices. On
 * handsets, the activity presents a list of items, which when touched,
 * lead to a {@link TodoDetailActivity} representing
 * item details. On tablets, the activity presents the list of items and
 * item details side-by-side using two vertical panes.
 */
public class TodoListActivity extends AppCompatActivity implements TodoCreateFragment.ITodoCreateFragment {

    private RecyclerView recyclerView;
    private SimpleItemRecyclerViewAdapter adapter;
    /**
     * Whether or not the activity is in two-pane mode, i.e. running on a tablet
     * device.
     */
    private boolean mTwoPane;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_list);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle(getTitle());

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        recyclerView = (RecyclerView) findViewById(R.id.todo_list);
        assert recyclerView != null;
        setupRecyclerView(recyclerView);
        adapter = (SimpleItemRecyclerViewAdapter) recyclerView.getAdapter();

        if (findViewById(R.id.todo_detail_container) != null) {
            // The detail container view will be present only in the
            // large-screen layouts (res/values-w900dp).
            // If this view is present, then the
            // activity should be in two-pane mode.
            mTwoPane = true;
        }
    }

    private void setupRecyclerView(@NonNull RecyclerView recyclerView) {
        ArrayList<Todo> todos = new ArrayList<Todo>();
        todos.add(new Todo("title1", Todo.Priority.LOW, "2011. 09. 26.", "description1"));
        todos.add(new Todo("title2", Todo.Priority.MEDIUM, "2011. 09. 27.", "description2"));
        todos.add(new Todo("title3", Todo.Priority.HIGH, "2011. 09. 28.", "description3"));
        recyclerView.setAdapter(new SimpleItemRecyclerViewAdapter(todos));
    }

    // ITodoCreateFragment
    @Override
    public void onTodoCreated(Todo newTodo) {
        adapter.addItem(newTodo);
        adapter.notifyDataSetChanged();
    }

    public class SimpleItemRecyclerViewAdapter
            extends RecyclerView.Adapter<SimpleItemRecyclerViewAdapter.ViewHolder> {

        private final List<Todo> todos;

        public SimpleItemRecyclerViewAdapter(List<Todo> todos) {
            this.todos = todos;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.todorow, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, final int position) {
            holder.mTodo = todos.get(position);
            holder.title.setText(todos.get(position).getTitle());
            holder.dueDate.setText(todos.get(position).getDueDate());

            switch (todos.get(position).getPriority()) {
                case LOW:
                    holder.priority.setImageResource(R.drawable.low);
                    break;
                case MEDIUM:
                    holder.priority.setImageResource(R.drawable.medium);
                    break;
                case HIGH:
                    holder.priority.setImageResource(R.drawable.high);
                    break;
                default:
                    holder.priority.setImageResource(R.drawable.high);
                    break;
            }

            holder.mView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mTwoPane) {
                        Bundle arguments = new Bundle();
                        arguments.putString(TodoDetailFragment.KEY_TODO_DESCRIPTION, todos.get(position).getDescription());
                        TodoDetailFragment fragment = new TodoDetailFragment();
                        fragment.setArguments(arguments);
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.todo_detail_container, fragment)
                                .commit();
                    } else {
                        Context context = v.getContext();
                        Intent intent = new Intent(context, TodoDetailActivity.class);
                        intent.putExtra(TodoDetailFragment.KEY_TODO_DESCRIPTION, todos.get(position).getDescription());

                        context.startActivity(intent);
                    }
                }
            });

            //!!!ide!!!!
            holder.mView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    PopupMenu popup = new PopupMenu(v.getContext(), v);
                    popup.inflate(R.menu.long_click_menu);
                    popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {
                            if (R.id.delete == item.getItemId()) {
                                deleteRow(position);
                            }
                            return false;
                        }
                    });
                    popup.show();
                    return false;
                }
            });
        }

        /**
         * Egy elem törlése
         */
        public void deleteRow(int position) {
            todos.remove(position);
            notifyDataSetChanged();
        }


        public void addItem(Todo aTodo) {
            todos.add(aTodo);
        }

        @Override
        public int getItemCount() {
            return todos.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public final View mView;
            public final TextView dueDate;
            public final TextView title;
            public final ImageView priority;
            public Todo mTodo;

            public ViewHolder(View view) {
                super(view);
                mView = view;
                title = (TextView) view.findViewById(R.id.textViewTitle);
                dueDate = (TextView) view.findViewById(R.id.textViewDueDate);
                priority = (ImageView) view.findViewById(R.id.imageViewPriority);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.listmenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.itemCreateTodo) {
            TodoCreateFragment createFragment = new TodoCreateFragment();
            android.support.v4.app.FragmentManager fm = getSupportFragmentManager();
            createFragment.show(fm, TodoCreateFragment.TAG);
        }
        return super.onOptionsItemSelected(item);
    }

}
